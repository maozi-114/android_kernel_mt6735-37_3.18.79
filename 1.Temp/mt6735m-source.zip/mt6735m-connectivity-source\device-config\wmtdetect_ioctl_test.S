.section .rodata
path:
	.asciz "/dev/wmtdetect"
msg_soc:
	.asciz "GET_SOC_CHIP_ID return: "
msg_init:
	.asciz "DO_MODULE_INIT return: "
newline:
	.asciz "\n"

.section .bss
	.align 3
out:
	.skip 32

.section .text
.global _start
_start:
	mov x0, -100
	adrp x1, path
	add x1, x1, :lo12:path
	mov x2, #0
	mov x3, #0
	mov x8, #56
	svc #0
	mov x19, x0
	cmp x0, #0
	b.ge 1f
	mov x0, #1
	mov x8, #93
	svc #0
1:
	mov x0, x19
	movz x1, #0x7703
	movk x1, #0x8004, lsl #16
	mov x2, #0
	mov x8, #29
	svc #0
	mov x20, x0
	adrp x0, msg_soc
	add x0, x0, :lo12:msg_soc
	bl print_prefix_and_value

	mov x0, x19
	movz x1, #0x7704
	movk x1, #0x8004, lsl #16
	movz x2, #0x6735
	mov x8, #29
	svc #0
	mov x20, x0
	adrp x0, msg_init
	add x0, x0, :lo12:msg_init
	bl print_prefix_and_value

	mov x0, #0
	mov x8, #93
	svc #0

print_prefix_and_value:
	mov x21, x0
	mov x2, #0
2:
	ldrb w3, [x21, x2]
	cbz w3, 3f
	add x2, x2, #1
	b 2b
3:
	mov x0, #1
	mov x1, x21
	mov x8, #64
	svc #0
	adrp x1, out
	add x1, x1, :lo12:out
	mov x0, x20
	mov x2, #0
	cmp x0, #0
	b.ge 4f
	mov w3, #'-'
	strb w3, [x1, x2]
	add x2, x2, #1
	neg x0, x0
4:
	mov x4, #10
	add x5, x1, #31
	mov w3, #0
	strb w3, [x5]
5:
	udiv x6, x0, x4
	msub x7, x6, x4, x0
	add x7, x7, #'0'
	sub x5, x5, #1
	strb w7, [x5]
	mov x0, x6
	cbnz x0, 5b
	mov x0, #1
	mov x1, x5
	adrp x6, out
	add x6, x6, :lo12:out
	add x6, x6, #31
	sub x2, x6, x5
	mov x8, #64
	svc #0
	mov x0, #1
	adrp x1, newline
	add x1, x1, :lo12:newline
	mov x2, #1
	mov x8, #64
	svc #0
	ret
