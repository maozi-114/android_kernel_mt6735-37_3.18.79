# MT6735M Android 8 Connectivity Source Package

## Scope

This package contains the source-side changes used to build the validated MT6735M connectivity stack and the merged DTB input/output required by this device. It does not contain vendor Bluetooth/WMT firmware files and does not replace Android boot or recovery images.

The package contains:

- `connectivity-modules/connectivity/`: external MediaTek connectivity module source tree.
- `kernel-patches/`: target-kernel source files changed for required connectivity exports and legacy module ABI compatibility.
- `device-config/dtb/`: corrected DT overlay source and the verified merged DTB.
- `device-config/`: connectivity init rc files and the WMT detect test source.

## Important Fixes

- Correct MT6735 CONSYS resource mapping, regulator voltage units, and partial-initialization cleanup.
- Build the external connectivity tree as compatible modules without internal dependency cycles.
- Preserve real WMT patch loading while normalizing launcher-provided patch basenames to absolute firmware paths at the kernel boundary.
- Disable only the confirmed MT6735 E1 (`u4HwVer = 0x8A00`) quick-PSM path. E2/E3 behavior remains unchanged.
- Make `/dev/stpbt` compatible with Android 8 HIDL reset and nonblocking-read behavior.
- Reassemble H4 byte-stream fragments from HIDL `writev()` calls before sending an STP packet. The former driver treated separate H4 type/header/payload writes as separate STP packets, which caused HCI Reset timeouts, STP TX-window exhaustion, and a whole-chip reset that also removed Wi-Fi.
- Fix the DT overlay phandle collision and package a complete merged DTB because LK does not load `odmdtbo`.

## Build Environment

Kernel tree:

```text
/home/maozi/orange_6735_3.18.79
```

Kernel output tree:

```text
/home/maozi/orange_6735_3.18.79/out
```

Build the external module tree with the target ARM64 toolchain and explicitly select the external COMBO and BT targets:

```sh
export ARCH=arm64
export SUBARCH=arm64
export PATH=/home/maozi/android-gcc-4.9/bin:$PATH
export CC=gcc
export CROSS_COMPILE=aarch64-linux-android-
export HOSTCFLAGS=-fcommon

make -j8 -C /home/maozi/orange_6735_3.18.79/out \
  M=$PWD/connectivity-modules/connectivity \
  CONFIG_MTK_COMBO=m CONFIG_MTK_COMBO_BT=m modules
```

`CONFIG_MTK_COMBO_BT=m` is required on the command line because the target kernel `.config` contains the built-in setting (`y`); otherwise `mtk_stp_bt_soc.ko` is not regenerated.

## Kernel Integration

Copy each file under `kernel-patches/` to its corresponding target-kernel path before rebuilding the target kernel. `module_workspace_copy.c` is a duplicate of the workspace-side `module.c`; `kernel-patches/module.c` is the file from the actual target kernel tree.

The module compatibility change bypasses only legacy ABI identity checks required by this device's external modules. ELF structure, architecture, relocations, and bounds validation remain in place.

## DTB

Use `device-config/dtb/base.dtbo.dts` to reproduce the fixed overlay. The final DTB must be the complete merged file `device-config/dtb/kernel_dtb_merged-fixed.dtb`, packaged as `kernel_dtb`. Do not rely on `odmdtbo` loading on this LK implementation.

## Validation Criteria

A successful Android test has all of the following:

```text
BluetoothManager: enabled: true, state: ON
Bluetooth crashed 0 times
wlan0: UP, LOWER_UP
```

Kernel logs must not contain `startup_timer_expired`, `command_timed_out`, `stp_do_tx_timeout`, `wmt_dev_rx_timeout`, patch-download failure, firmware assert, or whole-chip reset during Bluetooth enable.
