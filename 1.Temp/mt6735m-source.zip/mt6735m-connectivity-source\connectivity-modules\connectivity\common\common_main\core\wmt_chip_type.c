/*
 * MT6735 CONSYS builds have a fixed SoC connectivity implementation.
 * Keep this state local to wmt_drv so the core module does not depend on
 * the optional detect/ioctl dispatcher module.
 */
#include "wmt_detect.h"

ENUM_WMT_CHIP_TYPE wmt_detect_get_chip_type(void)
{
	return WMT_CHIP_TYPE_SOC;
}
