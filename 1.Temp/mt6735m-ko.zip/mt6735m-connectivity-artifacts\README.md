# MT6735M Android 8 Connectivity Artifacts

## Contents

This package contains the final, validated 9-module connectivity set and the complete merged device tree blob:

```text
modules/mtk_wmt_detect.ko
modules/wmt_drv.ko
modules/mtk_stp_bt_soc.ko
modules/stp_chrdev_gps.ko
modules/gps.ko
modules/gps_emi.ko
modules/mtk_fm_drv.ko
modules/wmt_chrdev_wifi.ko
modules/wlan_gen2.ko
kernel_dtb_merged-fixed.dtb
```

`SHA256SUMS` is authoritative. Verify it before deployment.

## Platform Compatibility

- SoC: MediaTek MT6735M / CONSYS 6735
- Kernel: Linux `3.18.79+`, ARM64
- Module vermagic: `3.18.79+ SMP preempt mod_unload modversions aarch64`
- Android: 8 HIDL Bluetooth path through `/dev/stpbt`

These artifacts require the corresponding kernel-side compatibility/export changes from the source package. Do not use them with an unrelated kernel.

## Deployment

Automatic connectivity module loading should remain disabled until recovery/TWRP validation has completed. Replace modules from recovery or another environment where all connectivity modules are inactive; do not unload `wmt_drv.ko` while Wi-Fi is active.

Expected vendor destination:

```text
/vendor/lib/modules/
```

The target must retain genuine vendor files under `/vendor/firmware/`, including `WMT_SOC.cfg` and the WMT patch firmware. Do not substitute placeholder firmware, fake STP ACKs, or synthetic HCI responses.

Example verification after copying:

```sh
sha256sum /vendor/lib/modules/mtk_wmt_detect.ko \
          /vendor/lib/modules/wmt_drv.ko \
          /vendor/lib/modules/mtk_stp_bt_soc.ko \
          /vendor/lib/modules/stp_chrdev_gps.ko \
          /vendor/lib/modules/gps.ko \
          /vendor/lib/modules/gps_emi.ko \
          /vendor/lib/modules/mtk_fm_drv.ko \
          /vendor/lib/modules/wmt_chrdev_wifi.ko \
          /vendor/lib/modules/wlan_gen2.ko
```

The complete merged DTB must be packaged as `kernel_dtb`; this LK does not load an `odmdtbo` partition.

## Verified Final State

- Bluetooth HCI Reset is transmitted as the complete H4 frame `01 03 0c 00`.
- Firmware returns STP ACK and HCI Command Complete.
- Android reports `enabled: true`, `state: ON`, and `Bluetooth crashed 0 times`.
- Settings exposes discovery and shows the existing paired device `真我GT5 Pro`.
- Wi-Fi remains `wlan0: UP, LOWER_UP` during Bluetooth startup and discovery.
- No HCI timeout, STP TX-window exhaustion, firmware assert, patch-download failure, or whole-chip reset occurred in final validation.

## Rollback

Use only a complete, hash-verified backup from the same device. Do not use an incomplete backup file produced when `/vendor` reported `No space left on device`.
